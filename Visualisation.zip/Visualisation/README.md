First prototype will visualise the data that are filtered and display the new result

## To DO
- [ ] 1.5 Table  containing the data should be visualised + some ascosiated variables


## DOING
- [ ] 1.4 Find a way to visulaise each row per time and allow user to move through rows


## DONE
- [X] 1.1 All modules should be visualised (all else if)


